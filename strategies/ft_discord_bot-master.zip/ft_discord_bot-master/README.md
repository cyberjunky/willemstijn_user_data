# Freqtrade Discord Bot

A discord bot to support the moderators and helpers in the FreqTrade discord channel.

+ Very simple command processing
+ Ability to push new changes and commands to the command list, then reload without restarting the bot
+ Basic search and rate limiting support available
